/* =========================================================
   MyVanguard — signup notifications
   Sends yourself an email whenever someone registers, using
   EmailJS (https://www.emailjs.com — free tier available).

   Your inbox address is NOT stored here. It's configured on
   EmailJS's dashboard as part of your email template, so it
   never appears in this file or anywhere in the page source.

   SETUP (one-time, ~5 minutes):
   1. Create a free account at emailjs.com.
   2. Add an "Email Service" (e.g. connect your Gmail) — this
      is where EmailJS gets permission to send on your behalf.
   3. Create an Email Template. In the template's "To email"
      field, put YOUR inbox address — this is the one place
      it's configured, and it stays on EmailJS's servers.
      In the template body, use variables {{name}} and
      {{email}} to show who signed up.
   4. Copy your Public Key, Service ID, and Template ID from
      the EmailJS dashboard into the CONFIG block below.
   5. Uncomment the EmailJS <script> tag in index.html's <head>.

   Until you fill in the CONFIG values, this module quietly
   does nothing — registration still works normally.
========================================================= */
(() => {
  'use strict';

  const CONFIG = {
    PUBLIC_KEY: '',      // e.g. 'AbCdEfGhIjKlMnOp'
    SERVICE_ID: '',      // e.g. 'service_xxxxxxx'
    TEMPLATE_ID: '',     // e.g. 'template_xxxxxxx'
  };

  function isConfigured() {
    return CONFIG.PUBLIC_KEY && CONFIG.SERVICE_ID && CONFIG.TEMPLATE_ID;
  }

  function notifyNewSignup({ name, email, createdAt }) {
    if (!isConfigured() || typeof emailjs === 'undefined') return;

    try {
      emailjs.init(CONFIG.PUBLIC_KEY);
      emailjs.send(CONFIG.SERVICE_ID, CONFIG.TEMPLATE_ID, {
        name,
        email,
        signed_up_at: new Date(createdAt).toLocaleString(),
        // Deliberately no password field — never sent, never logged.
      });
    } catch (err) {
      // Never let a notification failure block signup.
      console.warn('Signup notification failed to send.', err);
    }
  }

  window.MVMail = { notifyNewSignup };
})();
