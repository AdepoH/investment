(() => {
  'use strict';

  const fmtUSD = (n) => '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  function portfolioValue(user) {
    // Static valuation using each holding's avg buy price — good enough
    // for an admin list view; the live dashboard shows live pricing.
    return user.portfolio.holdings.reduce((sum, h) => sum + h.amount * h.avgBuy, 0);
  }

  function renderUsers() {
    const users = window.MVAuth.listUsersForAdmin();
    const body = document.getElementById('adminUsersBody');
    const empty = document.getElementById('adminEmptyState');
    document.getElementById('userCount').textContent = `${users.length} account${users.length === 1 ? '' : 's'}`;

    if (users.length === 0) {
      body.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';

    body.innerHTML = users.map(u => `
      <tr>
        <td><strong>${u.name}</strong></td>
        <td>${u.email}</td>
        <td>${new Date(u.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
        <td class="mono">${fmtUSD(portfolioValue(u))}</td>
        <td><button class="btn btn-outline admin-view-btn" data-id="${u.id}">View account</button></td>
      </tr>
    `).join('');

    body.querySelectorAll('.admin-view-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const result = window.MVAuth.startImpersonation(btn.dataset.id);
        if (result.ok) window.location.href = 'dashboard.html';
      });
    });
  }

  function showPanel() {
    document.getElementById('adminGate').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'grid';
    renderUsers();
  }

  document.addEventListener('DOMContentLoaded', () => {
    if (window.MVAuth.isAdminAuthed()) {
      showPanel();
    }

    document.getElementById('adminGateForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const passcode = document.getElementById('adminPasscode').value;
      const result = window.MVAuth.adminLogin(passcode);
      const errorEl = document.getElementById('adminGateError');
      if (result.ok) {
        showPanel();
      } else {
        errorEl.textContent = result.error;
        errorEl.classList.add('show');
      }
    });

    document.getElementById('adminLogoutBtn').addEventListener('click', () => {
      window.MVAuth.adminLogout();
      window.location.href = 'admin.html';
    });
  });
})();
