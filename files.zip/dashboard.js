(() => {
  'use strict';

  const isImpersonating = window.MVAuth && window.MVAuth.isAdminAuthed() && window.MVAuth.getImpersonatedUser();
  const user = isImpersonating
    ? window.MVAuth.getImpersonatedUser()
    : (window.MVAuth ? window.MVAuth.requireAuth() : null);
  if (!user) return; // requireAuth already redirected

  function initAdminBanner() {
    if (!isImpersonating) return;
    const banner = document.getElementById('adminBanner');
    document.getElementById('adminBannerText').textContent =
      `Admin view — viewing ${user.name}'s account (${user.email})`;
    banner.style.display = 'flex';
    document.getElementById('adminBannerExit').addEventListener('click', () => {
      window.MVAuth.stopImpersonation();
      window.location.href = 'admin.html';
    });
  }

  const CONFIG = { UPDATE_INTERVAL_MS: 3000, VOLATILITY: 0.006 };

  // Live mock prices — starting points close to the landing page's.
  const PRICES = { BTC: 96420.18, ETH: 3412.55, SOL: 214.72 };

  const fmtUSD = (n, decimals = 2) =>
    '$' + n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });

  const randomWalk = (price, volatility) => {
    const change = (Math.random() * 2 - 1) * volatility;
    return Math.max(price * (1 + change), 0.0001);
  };

  const { portfolio } = user;

  /* ===================== GREETING / HEADER ===================== */
  function initHeader() {
    const hour = new Date().getHours();
    const period = hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';
    document.getElementById('dashGreeting').textContent = `Good ${period}, ${user.name.split(' ')[0]}`;
    document.getElementById('dashDate').textContent = new Date().toLocaleDateString('en-US', {
      weekday: 'long', month: 'long', day: 'numeric', year: 'numeric',
    });
    const initials = user.name.split(' ').map(p => p[0]).join('').slice(0, 2).toUpperCase();
    document.getElementById('dashAvatar').textContent = initials;
  }

  /* ===================== TABS ===================== */
  function initTabs() {
    const navItems = document.querySelectorAll('.dash-nav-item');
    navItems.forEach((btn) => {
      btn.addEventListener('click', () => {
        navItems.forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.dash-tab').forEach((tab) => tab.classList.remove('active'));
        document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
      });
    });
  }

  /* ===================== HOLDINGS VALUE HELPERS ===================== */
  function holdingsMarketValue() {
    return portfolio.holdings.reduce((sum, h) => sum + h.amount * PRICES[h.asset], 0);
  }

  function costBasis() {
    return portfolio.holdings.reduce((sum, h) => sum + h.amount * h.avgBuy, 0);
  }

  /* ===================== OVERVIEW ===================== */
  let perfChart, allocChart;
  const perfHistory = buildPerfHistory();

  function buildPerfHistory() {
    // 30 mock daily points ending near current holdings value
    const points = [];
    let v = costBasis() * 0.97;
    for (let i = 0; i < 30; i++) {
      v = v * (1 + (Math.random() * 0.03 - 0.008));
      points.push(v);
    }
    return points;
  }

  function initOverview() {
    const deposited = portfolio.cashDeposited;
    const marketValue = holdingsMarketValue();
    const totalValue = marketValue; // holdings represent the full deployed portfolio
    const totalReturn = totalValue - costBasis() + (deposited - costBasis() > 0 ? 0 : 0);
    const returnPct = ((totalValue - costBasis()) / costBasis()) * 100;

    document.getElementById('statDeposited').textContent = fmtUSD(deposited, 0);
    document.getElementById('statPlan').textContent = portfolio.plan.name;

    const dayMs = 86400000;
    const elapsed = Math.floor((Date.now() - portfolio.plan.startedAt) / dayMs);
    const remaining = Math.max(portfolio.plan.termDays - elapsed, 0);
    const nextPayoutDays = Math.min(30 - (elapsed % 30), remaining);
    document.getElementById('statPayout').textContent = remaining === 0 ? 'Term complete' : `${nextPayoutDays}d`;

    updateOverviewLive(true);

    // Performance chart
    const ctx = document.getElementById('performanceChart');
    if (ctx && window.Chart) {
      perfChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: perfHistory.map((_, i) => i),
          datasets: [{
            data: perfHistory,
            borderColor: '#C9A227',
            backgroundColor: 'rgba(201,162,39,0.12)',
            fill: true,
            tension: 0.35,
            pointRadius: 0,
            borderWidth: 2,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false }, tooltip: { enabled: false } },
          scales: { x: { display: false }, y: { display: false } },
        },
      });
    }

    // Allocation chart
    const allocCtx = document.getElementById('allocationChart');
    const colors = { BTC: '#C9A227', ETH: '#4F9C6E', SOL: '#0B1220', Cash: '#B9B29A' };
    const labels = [...portfolio.holdings.map(h => h.asset)];
    const values = portfolio.holdings.map(h => h.amount * PRICES[h.asset]);

    if (allocCtx && window.Chart) {
      allocChart = new Chart(allocCtx, {
        type: 'doughnut',
        data: {
          labels,
          datasets: [{
            data: values,
            backgroundColor: labels.map(l => colors[l] || '#999'),
            borderWidth: 0,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '68%',
          plugins: { legend: { display: false } },
        },
      });
    }

    const legend = document.getElementById('allocationLegend');
    const total = values.reduce((a, b) => a + b, 0);
    legend.innerHTML = labels.map((l, i) => {
      const pct = ((values[i] / total) * 100).toFixed(1);
      return `<li><span class="legend-name"><span class="swatch" style="background:${colors[l] || '#999'}"></span>${l}</span><span class="legend-val">${pct}%</span></li>`;
    }).join('');

    // Recent activity
    const activity = document.getElementById('recentActivity');
    const recent = [...portfolio.transactions].sort((a, b) => b.date - a.date).slice(0, 5);
    activity.innerHTML = recent.map(t => `
      <li>
        <div class="act-main">
          <span class="act-type">${t.type} — ${t.asset}</span>
          <span class="act-date">${new Date(t.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
        </div>
        <span class="act-amount">${t.type === 'Deposit' || t.type === 'Payout' ? '+' : ''}${fmtUSD(t.amount)}</span>
      </li>
    `).join('');
  }

  function updateOverviewLive(first) {
    const marketValue = holdingsMarketValue();
    const basis = costBasis();
    const returnAmt = marketValue - basis;
    const returnPct = (returnAmt / basis) * 100;

    document.getElementById('dashTotalValue').textContent = fmtUSD(marketValue);
    const deltaEl = document.getElementById('dashTotalDelta');
    const up = returnPct >= 0;
    deltaEl.textContent = `${up ? '▲' : '▼'} ${Math.abs(returnPct).toFixed(2)}% all-time`;
    deltaEl.style.color = up ? 'var(--gain)' : 'var(--loss)';

    document.getElementById('statReturn').textContent = (returnAmt >= 0 ? '+' : '') + fmtUSD(returnAmt);
    document.getElementById('statReturn').style.color = returnAmt >= 0 ? 'var(--gain)' : 'var(--loss)';

    if (!first && perfChart) {
      perfHistory.shift();
      perfHistory.push(marketValue);
      perfChart.data.datasets[0].data = perfHistory;
      perfChart.update('none');
    }
  }

  /* ===================== HOLDINGS TAB ===================== */
  function renderHoldings() {
    const body = document.getElementById('holdingsBody');
    body.innerHTML = portfolio.holdings.map(h => {
      const price = PRICES[h.asset];
      const value = h.amount * price;
      const plAmt = value - h.amount * h.avgBuy;
      const plPct = (plAmt / (h.amount * h.avgBuy)) * 100;
      const cls = plAmt >= 0 ? 'pl-positive' : 'pl-negative';
      return `
        <tr data-asset="${h.asset}">
          <td><strong>${h.asset}</strong></td>
          <td class="mono">${h.amount}</td>
          <td class="mono">${fmtUSD(h.avgBuy)}</td>
          <td class="mono asset-price">${fmtUSD(price)}</td>
          <td class="mono asset-value">${fmtUSD(value)}</td>
          <td class="${cls} asset-pl">${plAmt >= 0 ? '+' : ''}${fmtUSD(plAmt)} (${plPct.toFixed(1)}%)</td>
        </tr>`;
    }).join('');
  }

  function updateHoldingsLive() {
    portfolio.holdings.forEach(h => {
      const row = document.querySelector(`#holdingsBody tr[data-asset="${h.asset}"]`);
      if (!row) return;
      const price = PRICES[h.asset];
      const value = h.amount * price;
      const plAmt = value - h.amount * h.avgBuy;
      const plPct = (plAmt / (h.amount * h.avgBuy)) * 100;
      row.querySelector('.asset-price').textContent = fmtUSD(price);
      row.querySelector('.asset-value').textContent = fmtUSD(value);
      const plCell = row.querySelector('.asset-pl');
      plCell.textContent = `${plAmt >= 0 ? '+' : ''}${fmtUSD(plAmt)} (${plPct.toFixed(1)}%)`;
      plCell.className = 'asset-pl ' + (plAmt >= 0 ? 'pl-positive' : 'pl-negative');
    });
  }

  /* ===================== TRANSACTIONS TAB ===================== */
  function renderTransactions() {
    const body = document.getElementById('transactionsBody');
    const sorted = [...portfolio.transactions].sort((a, b) => b.date - a.date);
    body.innerHTML = sorted.map(t => `
      <tr>
        <td>${new Date(t.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
        <td>${t.type}</td>
        <td>${t.asset}</td>
        <td class="mono">${fmtUSD(t.amount)}</td>
        <td><span class="status-badge">${t.status}</span></td>
      </tr>`).join('');
  }

  /* ===================== PLAN TAB ===================== */
  function renderPlan() {
    const plan = portfolio.plan;
    const dayMs = 86400000;
    const elapsed = Math.min(Math.floor((Date.now() - plan.startedAt) / dayMs), plan.termDays);
    const remaining = Math.max(plan.termDays - elapsed, 0);
    const pct = Math.min((elapsed / plan.termDays) * 100, 100);

    document.getElementById('planName').textContent = plan.name;
    document.getElementById('planApy').textContent = `${plan.apy}% APY`;
    document.getElementById('planProgressBar').style.width = pct + '%';
    document.getElementById('planElapsed').textContent = `Day ${elapsed} of ${plan.termDays}`;
    document.getElementById('planRemaining').textContent = `${remaining} days remaining`;

    const dailyRate = plan.apy / 100 / 365;
    const principal = costBasis();
    const projection = principal * Math.pow(1 + dailyRate, plan.termDays);
    document.getElementById('planProjection').textContent = fmtUSD(projection);
  }

  /* ===================== SETTINGS TAB ===================== */
  function initSettings() {
    document.getElementById('settingsName').value = user.name;
    document.getElementById('settingsEmail').value = user.email;

    const form = document.getElementById('passwordForm');
    const errorEl = document.getElementById('passwordError');
    const successEl = document.getElementById('passwordSuccess');
    const currentPasswordField = document.getElementById('currentPassword').closest('label');

    if (isImpersonating) {
      // Admin resetting a user's password doesn't need — or have — their old one.
      currentPasswordField.style.display = 'none';
      document.getElementById('currentPassword').required = false;
      form.querySelector('button[type="submit"]').textContent = 'Reset password for this user';
    }

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errorEl.classList.remove('show');
      successEl.classList.remove('show');

      const newPassword = document.getElementById('newPassword').value;

      const result = isImpersonating
        ? await window.MVAuth.adminResetPassword(newPassword)
        : await window.MVAuth.changePassword({
            currentPassword: document.getElementById('currentPassword').value,
            newPassword,
          });

      if (result.ok) {
        successEl.textContent = isImpersonating ? 'Password reset for this user.' : 'Password updated.';
        successEl.classList.add('show');
        form.reset();
      } else {
        errorEl.textContent = result.error;
        errorEl.classList.add('show');
      }
    });
  }

  /* ===================== LOGOUT ===================== */
  function initLogout() {
    document.getElementById('logoutBtn').addEventListener('click', () => {
      if (isImpersonating) {
        window.MVAuth.stopImpersonation();
        window.location.href = 'admin.html';
        return;
      }
      window.MVAuth.logout();
      window.location.href = 'index.html';
    });
  }

  /* ===================== LIVE TICK LOOP ===================== */
  function startLiveUpdates() {
    setInterval(() => {
      PRICES.BTC = randomWalk(PRICES.BTC, CONFIG.VOLATILITY);
      PRICES.ETH = randomWalk(PRICES.ETH, CONFIG.VOLATILITY);
      PRICES.SOL = randomWalk(PRICES.SOL, CONFIG.VOLATILITY);
      updateOverviewLive(false);
      updateHoldingsLive();
    }, CONFIG.UPDATE_INTERVAL_MS);
  }

  document.addEventListener('DOMContentLoaded', () => {
    initAdminBanner();
    initHeader();
    initTabs();
    initOverview();
    renderHoldings();
    renderTransactions();
    renderPlan();
    initSettings();
    initLogout();
    startLiveUpdates();
  });
})();
