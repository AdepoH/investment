/* =========================================================
   MyVanguard — client-side auth
   No server exists for this static site, so accounts and
   sessions are persisted in the browser via localStorage.
   Passwords are hashed (SHA-256) before storage — never
   stored in plaintext. This is real, working auth logic;
   it just runs client-side instead of against a database.
========================================================= */
(() => {
  'use strict';

  const USERS_KEY = 'myvanguard_users';
  const SESSION_KEY = 'myvanguard_session';
  const ADMIN_SESSION_KEY = 'myvanguard_admin_session';
  const ADMIN_VIEW_KEY = 'myvanguard_admin_viewing';

  // Change this before you rely on the admin panel. It's a client-side
  // gate only — visible to anyone who reads the JS — fine for a demo,
  // not a substitute for real server-side auth.
  const ADMIN_PASSCODE = 'change-this-admin-passcode';

  async function hashPassword(password) {
    const enc = new TextEncoder().encode(password);
    const buf = await crypto.subtle.digest('SHA-256', enc);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  function getUsers() {
    try {
      return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
    } catch {
      return [];
    }
  }

  function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  function emailExists(email) {
    return getUsers().some(u => u.email.toLowerCase() === email.toLowerCase());
  }

  // Seeds a starter portfolio for a brand-new account so the
  // dashboard isn't empty on first login.
  function seedPortfolio() {
    const now = Date.now();
    const day = 86400000;
    return {
      cashDeposited: 5000,
      holdings: [
        { asset: 'BTC', amount: 0.031, avgBuy: 91200 },
        { asset: 'ETH', amount: 0.62, avgBuy: 3180 },
        { asset: 'SOL', amount: 4.1, avgBuy: 198 },
      ],
      transactions: [
        { date: now - day * 34, type: 'Deposit', asset: 'USD', amount: 5000, status: 'Completed' },
        { date: now - day * 33, type: 'Allocation', asset: 'BTC', amount: 2800, status: 'Completed' },
        { date: now - day * 33, type: 'Allocation', asset: 'ETH', amount: 1970, status: 'Completed' },
        { date: now - day * 33, type: 'Allocation', asset: 'SOL', amount: 230, status: 'Completed' },
        { date: now - day * 12, type: 'Payout', asset: 'USD', amount: 84.20, status: 'Completed' },
      ],
      plan: { name: 'Momentum', apy: 14.2, termDays: 90, startedAt: now - day * 33 },
    };
  }

  async function registerUser({ name, email, password }) {
    if (!name || !email || !password) return { ok: false, error: 'All fields are required.' };
    if (password.length < 8) return { ok: false, error: 'Password must be at least 8 characters.' };
    if (emailExists(email)) return { ok: false, error: 'An account with this email already exists.' };

    const passwordHash = await hashPassword(password);
    const user = {
      id: 'u_' + Date.now().toString(36),
      name,
      email,
      passwordHash,
      createdAt: Date.now(),
      portfolio: seedPortfolio(),
    };

    const users = getUsers();
    users.push(user);
    saveUsers(users);

    createSession(user);

    // Fire-and-forget notification — never includes the password.
    if (window.MVMail) {
      window.MVMail.notifyNewSignup({ name, email, createdAt: user.createdAt });
    }

    return { ok: true, user };
  }

  async function loginUser({ email, password }) {
    if (!email || !password) return { ok: false, error: 'Enter your email and password.' };
    const users = getUsers();
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) return { ok: false, error: 'No account found with that email.' };

    const passwordHash = await hashPassword(password);
    if (passwordHash !== user.passwordHash) return { ok: false, error: 'Incorrect password.' };

    createSession(user);
    return { ok: true, user };
  }

  function createSession(user) {
    localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: user.id, loggedInAt: Date.now() }));
  }

  function getSession() {
    try {
      return JSON.parse(localStorage.getItem(SESSION_KEY));
    } catch {
      return null;
    }
  }

  function getCurrentUser() {
    const session = getSession();
    if (!session) return null;
    return getUsers().find(u => u.id === session.userId) || null;
  }

  function updateCurrentUser(patch) {
    const session = getSession();
    if (!session) return null;
    return updateUserById(session.userId, patch);
  }

  function updateUserById(userId, patch) {
    const users = getUsers();
    const idx = users.findIndex(u => u.id === userId);
    if (idx === -1) return null;
    users[idx] = { ...users[idx], ...patch };
    saveUsers(users);
    return users[idx];
  }

  async function changePassword({ currentPassword, newPassword }) {
    const user = getCurrentUser();
    if (!user) return { ok: false, error: 'Not logged in.' };
    if (newPassword.length < 8) return { ok: false, error: 'New password must be at least 8 characters.' };

    const currentHash = await hashPassword(currentPassword);
    if (currentHash !== user.passwordHash) return { ok: false, error: 'Current password is incorrect.' };

    const newHash = await hashPassword(newPassword);
    updateCurrentUser({ passwordHash: newHash });
    return { ok: true };
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
  }

  // Redirects to the landing page if there's no active session.
  // Call at the top of any protected page.
  function requireAuth() {
    if (!getSession()) {
      window.location.href = 'index.html';
      return null;
    }
    const user = getCurrentUser();
    if (!user) {
      logout();
      window.location.href = 'index.html';
      return null;
    }
    return user;
  }

  /* ===================== ADMIN ===================== */
  function adminLogin(passcode) {
    if (passcode !== ADMIN_PASSCODE) return { ok: false, error: 'Incorrect passcode.' };
    sessionStorage.setItem(ADMIN_SESSION_KEY, '1');
    return { ok: true };
  }

  function isAdminAuthed() {
    return sessionStorage.getItem(ADMIN_SESSION_KEY) === '1';
  }

  function adminLogout() {
    sessionStorage.removeItem(ADMIN_SESSION_KEY);
    sessionStorage.removeItem(ADMIN_VIEW_KEY);
  }

  // Returns every account's non-sensitive info. passwordHash is
  // deliberately stripped — even the admin panel never surfaces it,
  // and it couldn't be turned back into a plaintext password anyway.
  function listUsersForAdmin() {
    if (!isAdminAuthed()) return [];
    return getUsers().map(({ passwordHash, ...safe }) => safe);
  }

  // Lets an authenticated admin open a user's dashboard to help with
  // an issue, without ever needing or seeing that user's password.
  function startImpersonation(userId) {
    if (!isAdminAuthed()) return { ok: false, error: 'Not authenticated as admin.' };
    const user = getUsers().find(u => u.id === userId);
    if (!user) return { ok: false, error: 'User not found.' };
    sessionStorage.setItem(ADMIN_VIEW_KEY, userId);
    return { ok: true };
  }

  function getImpersonatedUser() {
    if (!isAdminAuthed()) return null;
    const userId = sessionStorage.getItem(ADMIN_VIEW_KEY);
    if (!userId) return null;
    return getUsers().find(u => u.id === userId) || null;
  }

  function stopImpersonation() {
    sessionStorage.removeItem(ADMIN_VIEW_KEY);
  }

  // Lets an admin set a new password for the account they're currently
  // viewing — for unblocking a locked-out user. Requires an active
  // admin session and impersonation; never requires the old password.
  async function adminResetPassword(newPassword) {
    if (!isAdminAuthed()) return { ok: false, error: 'Not authenticated as admin.' };
    const userId = sessionStorage.getItem(ADMIN_VIEW_KEY);
    if (!userId) return { ok: false, error: 'No account selected.' };
    if (newPassword.length < 8) return { ok: false, error: 'New password must be at least 8 characters.' };

    const newHash = await hashPassword(newPassword);
    updateUserById(userId, { passwordHash: newHash });
    return { ok: true };
  }

  window.MVAuth = {
    registerUser,
    loginUser,
    changePassword,
    logout,
    getSession,
    getCurrentUser,
    updateCurrentUser,
    requireAuth,
    adminLogin,
    isAdminAuthed,
    adminLogout,
    listUsersForAdmin,
    startImpersonation,
    getImpersonatedUser,
    stopImpersonation,
    adminResetPassword,
  };
})();
